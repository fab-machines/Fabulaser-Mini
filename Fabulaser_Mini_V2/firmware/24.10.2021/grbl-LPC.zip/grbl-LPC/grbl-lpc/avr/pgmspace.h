#define PSTR(s) s

inline char pgm_read_byte_near(const char* p) {return *p;}
